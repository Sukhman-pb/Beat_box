#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include "hal/i2c_bus.h"
#include "hal/helper.h"
int16_t read_axis(int i2c_fd, uint8_t reg_l, uint8_t reg_h) {
    //write_register_8(i2c_fd, REG_CONFIGURATION, reg_l);
    //sleep_ms(50);
    uint8_t lsb = read_register_8(i2c_fd, reg_l);  // Read Low Byte
    sleep_ms(50);
    //write_register_8(i2c_fd, REG_CONFIGURATION, reg_h);
    //sleep_ms(50);
    uint8_t msb = read_register_8(i2c_fd, reg_h);  // Read High Byte
    sleep_ms(50);
    int16_t value = ((msb << 8) | lsb);  // Combine into 16-bit signed value
    return value >>2;
}

int main() {
    // Initialize I2C Bus
    int i2c_fd = init_i2c_bus(I2CDRV_LINUX_BUS, ACCEL_ADDRESS);

    printf("I2C Accelerometer Communication Started (Press CTRL+C to Stop)\n");

    // ✅ Configure the accelerometer
    write_register_8(i2c_fd, CTRL1, CTRL1_VALUE);
    write_register_8(i2c_fd, CTRL2, CTRL2_VALUE);
    write_register_8(i2c_fd, CTRL4, CTRL4_VALUE);
    write_register_8(i2c_fd, CTRL5, CTRL5_VALUE);

    printf("Accelerometer Configured\n");
    printf("Accelerometer --------------\n");

    while(true){

        int16_t x = read_axis(i2c_fd, OUT_X_L, OUT_X_H);
        int16_t y = read_axis(i2c_fd, OUT_Y_L, OUT_Y_H);
        int16_t z = read_axis(i2c_fd, OUT_Z_L, OUT_Z_H);
        printf("X: %d, Y: %d, Z: %d\n", x, y, z);
        sleep_ms(1000);
    }
    // Close I2C Bus (this will never be reached unless loop is exited)
    close_i2c_bus(i2c_fd);
    printf("Accelerometer closed");

    return 0;
}
